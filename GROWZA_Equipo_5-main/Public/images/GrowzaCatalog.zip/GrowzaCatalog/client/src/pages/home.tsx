import { useState, useEffect } from 'react';
import { Heart, ShoppingCart, Leaf, Carrot, Coffee, Cookie, Globe } from 'lucide-react';
import { Product, CartItem, ProductCategory } from '@/types/product';
import { ProductCard } from '@/components/product-card';
import { FavoritesSection } from '@/components/favorites-section';
import { CartSection } from '@/components/cart-section';
import { useLocalStorage } from '@/hooks/use-local-storage';

const SAMPLE_PRODUCTS: Product[] = [
  { 
    id: 1, 
    name: "Zanahorias Orgánicas", 
    price: 24.50, 
    image: "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Vegetales", 
    icon: "fas fa-carrot",
    nutrition: {
      energia: 41,
      proteina: 0.9,
      carbohidratos: 9.6,
      fibra: 2.8,
      vitaminas: ["Vitamina A", "Vitamina K", "Vitamina C"],
      minerales: ["Potasio", "Manganeso"]
    },
    benefits: "Las zanahorias son ricas en betacaroteno que se convierte en Vitamina A, esencial para la salud de los ojos 👀 y la piel ✨"
  },
  { 
    id: 2, 
    name: "Espinacas Frescas", 
    price: 18.90, 
    image: "https://images.unsplash.com/photo-1576045057995-568f588f82fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Vegetales", 
    icon: "fas fa-leaf",
    nutrition: {
      energia: 23,
      proteina: 2.9,
      carbohidratos: 3.6,
      fibra: 2.2,
      vitaminas: ["Vitamina K", "Ácido Fólico", "Vitamina C"],
      minerales: ["Hierro", "Calcio", "Magnesio"]
    },
    benefits: "Las espinacas son una fuente excelente de hierro y ácido fólico, ideales para fortalecer la sangre 🩸 y prevenir la anemia 💪"
  },
  { 
    id: 3, 
    name: "Jugo Verde Natural", 
    price: 32.00, 
    image: "https://images.unsplash.com/photo-1610970881699-44a5587cabec?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Bebidas", 
    icon: "fas fa-glass-whiskey",
    nutrition: {
      energia: 45,
      proteina: 2.1,
      carbohidratos: 9.8,
      fibra: 3.1,
      vitaminas: ["Vitamina C", "Vitamina A", "Vitamina K"],
      minerales: ["Potasio", "Magnesio", "Hierro"]
    },
    benefits: "Este jugo verde concentra nutrientes de vegetales frescos que ayudan a desintoxicar el cuerpo 🌿 y aumentar la energía ⚡"
  },
  { 
    id: 4, 
    name: "Nueces Mixtas", 
    price: 45.50, 
    image: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Snacks", 
    icon: "fas fa-seedling",
    nutrition: {
      energia: 618,
      proteina: 15.2,
      carbohidratos: 13.7,
      fibra: 6.7,
      vitaminas: ["Vitamina E", "Vitamina B6", "Niacina"],
      minerales: ["Magnesio", "Fósforo", "Zinc"]
    },
    benefits: "Las nueces son ricas en omega-3 y vitamina E, excelentes para la salud del corazón ❤️ y la función cerebral 🧠"
  },
  { 
    id: 5, 
    name: "Brócoli Orgánico", 
    price: 28.75, 
    image: "https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Vegetales", 
    icon: "fas fa-tree",
    nutrition: {
      energia: 34,
      proteina: 2.8,
      carbohidratos: 6.6,
      fibra: 2.6,
      vitaminas: ["Vitamina C", "Vitamina K", "Ácido Fólico"],
      minerales: ["Potasio", "Hierro", "Calcio"]
    },
    benefits: "El brócoli es un súper alimento rico en antioxidantes que fortalece el sistema inmunológico 🛡️ y combate la inflamación 🌟"
  },
  { 
    id: 6, 
    name: "Agua Mineral Natural", 
    price: 15.00, 
    image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Bebidas", 
    icon: "fas fa-tint",
    nutrition: {
      energia: 0,
      proteina: 0,
      carbohidratos: 0,
      fibra: 0,
      vitaminas: [],
      minerales: ["Calcio", "Magnesio", "Sodio"]
    },
    benefits: "El agua mineral hidrata y aporta minerales esenciales para mantener el equilibrio electrolítico del cuerpo 💧✨"
  },
  { 
    id: 7, 
    name: "Granola Casera", 
    price: 38.20, 
    image: "https://images.unsplash.com/photo-1571115764595-644a1f56a55c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Snacks", 
    icon: "fas fa-cookie",
    nutrition: {
      energia: 471,
      proteina: 12.8,
      carbohidratos: 56.3,
      fibra: 8.9,
      vitaminas: ["Vitamina E", "Tiamina", "Niacina"],
      minerales: ["Magnesio", "Fósforo", "Manganeso"]
    },
    benefits: "La granola casera proporciona energía duradera y fibra que ayuda a mantener la saciedad y la salud digestiva 🌾💪"
  },
  { 
    id: 8, 
    name: "Tomates Cherry", 
    price: 26.90, 
    image: "https://images.unsplash.com/photo-1546470427-e5f89a4b0746?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Vegetales", 
    icon: "fas fa-circle",
    nutrition: {
      energia: 18,
      proteina: 0.9,
      carbohidratos: 3.9,
      fibra: 1.2,
      vitaminas: ["Vitamina C", "Vitamina A", "Vitamina K"],
      minerales: ["Potasio", "Manganeso"]
    },
    benefits: "Los tomates cherry son ricos en licopeno, un antioxidante que protege la piel del sol ☀️ y favorece la salud cardiovascular ❤️"
  },
  { 
    id: 9, 
    name: "Té Verde Orgánico", 
    price: 42.00, 
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Bebidas", 
    icon: "fas fa-mug-hot",
    nutrition: {
      energia: 1,
      proteina: 0.2,
      carbohidratos: 0,
      fibra: 0,
      vitaminas: ["Vitamina C", "Vitamina E"],
      minerales: ["Manganeso", "Fluoruro"]
    },
    benefits: "El té verde contiene antioxidantes naturales que aceleran el metabolismo 🔥 y mejoran la concentración mental 🧘‍♀️"
  },
  { 
    id: 10, 
    name: "Frutas Deshidratadas", 
    price: 35.60, 
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Snacks", 
    icon: "fas fa-apple-alt",
    nutrition: {
      energia: 245,
      proteina: 2.3,
      carbohidratos: 65.8,
      fibra: 7.1,
      vitaminas: ["Vitamina A", "Vitamina C", "Vitamina E"],
      minerales: ["Potasio", "Hierro", "Calcio"]
    },
    benefits: "Las frutas deshidratadas conservan las vitaminas y proporcionan energía natural 🍎⚡ ideal para deportistas y estudiantes 📚"
  },
  { 
    id: 11, 
    name: "Apio Fresco", 
    price: 22.40, 
    image: "https://images.unsplash.com/photo-1601001815894-4bb6c81416d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Vegetales", 
    icon: "fas fa-leaf",
    nutrition: {
      energia: 14,
      proteina: 0.7,
      carbohidratos: 3.0,
      fibra: 1.6,
      vitaminas: ["Vitamina K", "Vitamina C", "Ácido Fólico"],
      minerales: ["Potasio", "Sodio", "Calcio"]
    },
    benefits: "El apio tiene propiedades diuréticas naturales que ayudan a eliminar toxinas 🌿 y reducir la retención de líquidos 💧"
  },
  { 
    id: 12, 
    name: "Smoothie Tropical", 
    price: 29.80, 
    image: "https://images.unsplash.com/photo-1505252585461-04db1eb84625?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300", 
    category: "Bebidas", 
    icon: "fas fa-cocktail",
    nutrition: {
      energia: 89,
      proteina: 1.8,
      carbohidratos: 22.1,
      fibra: 3.4,
      vitaminas: ["Vitamina C", "Vitamina A", "Vitamina B6"],
      minerales: ["Potasio", "Magnesio", "Manganeso"]
    },
    benefits: "Este smoothie tropical aporta enzimas digestivas naturales 🥭 y vitamina C que fortalece las defensas del cuerpo 🛡️"
  }
];

export default function Home() {
  const [products, setProducts] = useLocalStorage<Product[]>('growza_products', []);
  const [favorites, setFavorites] = useLocalStorage<Product[]>('growza_favorites', []);
  const [cart, setCart] = useLocalStorage<CartItem[]>('growza_cart', []);
  
  const [currentFilter, setCurrentFilter] = useState<ProductCategory>('all');
  const [showFavorites, setShowFavorites] = useState(false);
  const [showCart, setShowCart] = useState(false);

  // Initialize products with sample data if empty
  useEffect(() => {
    if (products.length === 0) {
      setProducts(SAMPLE_PRODUCTS);
    }
  }, [products.length, setProducts]);

  const filteredProducts = currentFilter === 'all' 
    ? products 
    : products.filter(product => product.category === currentFilter);

  const toggleFavorite = (productId: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existingIndex = favorites.findIndex(fav => fav.id === productId);
    if (existingIndex > -1) {
      setFavorites(favorites.filter(fav => fav.id !== productId));
    } else {
      setFavorites([...favorites, product]);
    }
  };

  const addToCart = (productId: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
      setCart(cart.map(item =>
        item.id === productId
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const updateCartQuantity = (productId: number, change: number) => {
    const item = cart.find(item => item.id === productId);
    if (!item) return;

    const newQuantity = item.quantity + change;
    if (newQuantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart(cart.map(item =>
        item.id === productId
          ? { ...item, quantity: newQuantity }
          : item
      ));
    }
  };

  const removeFromCart = (productId: number) => {
    setCart(cart.filter(item => item.id !== productId));
  };

  const toggleFavoritesSection = () => {
    setShowFavorites(!showFavorites);
    setShowCart(false);
  };

  const toggleCartSection = () => {
    setShowCart(!showCart);
    setShowFavorites(false);
  };

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="bg-gradient-to-br from-leaf to-cream min-h-screen font-rounded paw-print">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-forest rounded-full flex items-center justify-center">
                <Leaf className="text-white w-5 h-5" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-forest">Growza</h1>
                <p className="text-sm text-earth">Tienda Ecológica</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button 
                onClick={toggleFavoritesSection}
                className="relative p-3 bg-red-50 hover:bg-red-100 rounded-full transition-all duration-300"
              >
                <Heart className="text-red-500 w-5 h-5" />
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-semibold">
                  {favorites.length}
                </span>
              </button>
              <button 
                onClick={toggleCartSection}
                className="relative p-3 bg-forest/10 hover:bg-forest/20 rounded-full transition-all duration-300"
              >
                <ShoppingCart className="text-forest w-5 h-5" />
                <span className="absolute -top-2 -right-2 bg-forest text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-semibold">
                  {totalCartItems}
                </span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Category Filters */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-forest mb-4 flex items-center">
            <Leaf className="mr-2 w-6 h-6" />
            Nuestros Productos Naturales
          </h2>
          <div className="flex flex-wrap gap-3">
            <button 
              onClick={() => setCurrentFilter('all')}
              className={`category-filter ${currentFilter === 'all' ? 'active' : ''}`}
            >
              <Globe className="w-4 h-4 mr-2" />Todos
            </button>
            <button 
              onClick={() => setCurrentFilter('Vegetales')}
              className={`category-filter ${currentFilter === 'Vegetales' ? 'active' : ''}`}
            >
              <Carrot className="w-4 h-4 mr-2" />Vegetales
            </button>
            <button 
              onClick={() => setCurrentFilter('Bebidas')}
              className={`category-filter ${currentFilter === 'Bebidas' ? 'active' : ''}`}
            >
              <Coffee className="w-4 h-4 mr-2" />Bebidas
            </button>
            <button 
              onClick={() => setCurrentFilter('Snacks')}
              className={`category-filter ${currentFilter === 'Snacks' ? 'active' : ''}`}
            >
              <Cookie className="w-4 h-4 mr-2" />Snacks
            </button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              isFavorite={favorites.some(fav => fav.id === product.id)}
              onToggleFavorite={toggleFavorite}
              onAddToCart={addToCart}
            />
          ))}
        </div>

        {/* Favorites Section */}
        {showFavorites && (
          <section className="mb-12">
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
              <h3 className="text-2xl font-semibold text-red-500 mb-6 flex items-center">
                <Heart className="mr-3 w-6 h-6" />Mis Favoritos
                <span className="ml-2 w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-sm font-bold text-red-600">
                  {favorites.length}
                </span>
              </h3>
              <FavoritesSection
                favorites={favorites}
                onToggleFavorite={toggleFavorite}
                onAddToCart={addToCart}
              />
            </div>
          </section>
        )}

        {/* Cart Section */}
        {showCart && (
          <section>
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
              <h3 className="text-2xl font-semibold text-forest mb-6 flex items-center justify-between">
                <div className="flex items-center">
                  <ShoppingCart className="mr-3 w-6 h-6" />Mi Carrito
                  <span className="ml-2 w-8 h-8 bg-forest/20 rounded-full flex items-center justify-center text-sm font-bold text-forest">
                    {totalCartItems}
                  </span>
                </div>
              </h3>
              <CartSection
                cart={cart}
                onUpdateQuantity={updateCartQuantity}
                onRemoveFromCart={removeFromCart}
              />
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
