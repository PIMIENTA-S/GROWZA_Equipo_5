export interface NutritionalInfo {
  energia: number; // kcal
  proteina: number; // g
  carbohidratos: number; // g
  fibra: number; // g
  vitaminas: string[];
  minerales: string[];
}

export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: 'Vegetales' | 'Bebidas' | 'Snacks';
  icon: string;
  nutrition: NutritionalInfo;
  benefits: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type ProductCategory = 'all' | 'Vegetales' | 'Bebidas' | 'Snacks';
