import { ShoppingCart, Plus, Minus, Trash2, CreditCard } from 'lucide-react';
import { CartItem } from '@/types/product';

interface CartSectionProps {
  cart: CartItem[];
  onUpdateQuantity: (productId: number, change: number) => void;
  onRemoveFromCart: (productId: number) => void;
}

export function CartSection({ cart, onUpdateQuantity, onRemoveFromCart }: CartSectionProps) {
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  if (cart.length === 0) {
    return (
      <div className="text-center py-8">
        <ShoppingCart className="w-16 h-16 text-green-200 mx-auto mb-4" />
        <p className="text-gray-500 text-lg">Tu carrito está vacío</p>
        <p className="text-gray-400">¡Agrega algunos productos deliciosos!</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-4 mb-6">
        {cart.map(item => (
          <div key={item.id} className="flex items-center bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300">
            <img 
              src={item.image} 
              alt={item.name} 
              className="w-16 h-16 object-cover rounded-lg mr-4"
            />
            <div className="flex-1">
              <h4 className="font-semibold text-gray-800">{item.name}</h4>
              <p className="text-forest font-bold">${item.price.toFixed(2)}</p>
            </div>
            <div className="flex items-center space-x-3">
              <button 
                onClick={() => onUpdateQuantity(item.id, -1)}
                className="w-8 h-8 bg-red-100 hover:bg-red-200 text-red-600 rounded-full flex items-center justify-center transition-all duration-300"
              >
                <Minus className="w-3 h-3" />
              </button>
              <span className="font-semibold text-lg w-8 text-center">{item.quantity}</span>
              <button 
                onClick={() => onUpdateQuantity(item.id, 1)}
                className="w-8 h-8 bg-forest/20 hover:bg-forest/30 text-forest rounded-full flex items-center justify-center transition-all duration-300"
              >
                <Plus className="w-3 h-3" />
              </button>
              <button 
                onClick={() => onRemoveFromCart(item.id)}
                className="ml-4 text-red-500 hover:bg-red-50 p-2 rounded-full transition-all duration-300"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-between items-center mb-6">
        <div className="text-lg font-bold text-forest">
          Total: ${totalPrice.toFixed(2)} ({totalItems} productos)
        </div>
      </div>
      <div className="flex justify-end">
        <button className="bg-forest hover:bg-forest/90 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105">
          <CreditCard className="w-5 h-5 mr-2 inline" />
          Proceder al Pago
        </button>
      </div>
    </>
  );
}
