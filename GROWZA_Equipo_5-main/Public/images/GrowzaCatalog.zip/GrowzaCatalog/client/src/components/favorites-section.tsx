import { Heart, ShoppingCart, HeartCrack } from 'lucide-react';
import { Product } from '@/types/product';

interface FavoritesSectionProps {
  favorites: Product[];
  onToggleFavorite: (productId: number) => void;
  onAddToCart: (productId: number) => void;
}

export function FavoritesSection({ favorites, onToggleFavorite, onAddToCart }: FavoritesSectionProps) {
  if (favorites.length === 0) {
    return (
      <div className="col-span-full text-center py-8">
        <Heart className="w-16 h-16 text-red-200 mx-auto mb-4" />
        <p className="text-gray-500 text-lg">No tienes productos favoritos aún</p>
        <p className="text-gray-400">¡Explora nuestros productos y marca tus favoritos!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {favorites.map(product => (
        <div key={product.id} className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-32 object-cover rounded-lg mb-3"
          />
          <h4 className="font-semibold text-gray-800">{product.name}</h4>
          <p className="text-forest font-bold">${product.price.toFixed(2)}</p>
          <div className="mt-3 flex justify-between">
            <button 
              onClick={() => onToggleFavorite(product.id)}
              className="text-red-500 hover:bg-red-50 p-2 rounded-full transition-all duration-300"
            >
              <HeartCrack className="w-5 h-5" />
            </button>
            <button 
              onClick={() => onAddToCart(product.id)}
              className="bg-forest hover:bg-forest/90 text-white px-3 py-1 rounded-full text-sm transition-all duration-300"
            >
              <ShoppingCart className="w-4 h-4 mr-1 inline" />
              Agregar
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
