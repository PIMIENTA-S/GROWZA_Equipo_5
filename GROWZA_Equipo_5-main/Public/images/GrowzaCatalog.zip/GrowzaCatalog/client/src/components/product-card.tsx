import { Heart, ShoppingCart, Info, Zap } from 'lucide-react';
import { Product } from '@/types/product';
import { cn } from '@/lib/utils';
import { useState } from 'react';

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  onToggleFavorite: (productId: number) => void;
  onAddToCart: (productId: number) => void;
}

export function ProductCard({ product, isFavorite, onToggleFavorite, onAddToCart }: ProductCardProps) {
  const [showNutrition, setShowNutrition] = useState(false);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(product.id);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product.id);
  };

  const toggleNutrition = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowNutrition(!showNutrition);
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 overflow-hidden">
      <div className="relative">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-3 right-3 flex space-x-2">
          <button 
            onClick={toggleNutrition}
            className="w-10 h-10 bg-sage/80 hover:bg-sage text-white rounded-full flex items-center justify-center transition-all duration-300"
            title="Ver información nutricional"
          >
            <Info className="w-5 h-5" />
          </button>
          <button 
            onClick={handleFavoriteClick}
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300",
              isFavorite 
                ? "bg-red-500 text-white" 
                : "bg-white/70 text-red-500 hover:bg-red-100"
            )}
          >
            <Heart className={cn("w-5 h-5", isFavorite && "fill-current")} />
          </button>
        </div>
        <div className="absolute top-3 left-3">
          <span className="bg-forest/90 text-white px-3 py-1 rounded-full text-sm font-semibold">
            <i className={`${product.icon} mr-1`}></i>
            {product.category}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-lg text-gray-800 mb-2">{product.name}</h3>
        
        {/* Benefits Section */}
        <div className="mb-3 p-3 bg-leaf/30 rounded-xl">
          <div className="flex items-start space-x-2">
            <Zap className="w-4 h-4 text-sage mt-0.5 flex-shrink-0" />
            <p className="text-sm text-gray-700 leading-relaxed">{product.benefits}</p>
          </div>
        </div>

        {/* Nutritional Information - Expandable */}
        {showNutrition && (
          <div className="mb-4 p-3 bg-cream/50 rounded-xl border border-sage/20">
            <h4 className="font-semibold text-sm text-forest mb-2 flex items-center">
              <Info className="w-4 h-4 mr-1" />
              Información Nutricional (por 100g)
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-white/60 p-2 rounded-lg">
                <span className="font-medium text-gray-600">Energía:</span>
                <span className="ml-1 font-bold text-forest">{product.nutrition.energia} kcal</span>
              </div>
              <div className="bg-white/60 p-2 rounded-lg">
                <span className="font-medium text-gray-600">Proteína:</span>
                <span className="ml-1 font-bold text-forest">{product.nutrition.proteina}g</span>
              </div>
              <div className="bg-white/60 p-2 rounded-lg">
                <span className="font-medium text-gray-600">Carboh.:</span>
                <span className="ml-1 font-bold text-forest">{product.nutrition.carbohidratos}g</span>
              </div>
              <div className="bg-white/60 p-2 rounded-lg">
                <span className="font-medium text-gray-600">Fibra:</span>
                <span className="ml-1 font-bold text-forest">{product.nutrition.fibra}g</span>
              </div>
            </div>
            {product.nutrition.vitaminas.length > 0 && (
              <div className="mt-2">
                <p className="text-xs font-medium text-gray-600 mb-1">Vitaminas:</p>
                <div className="flex flex-wrap gap-1">
                  {product.nutrition.vitaminas.map((vitamin, index) => (
                    <span key={index} className="bg-sage/20 text-sage text-xs px-2 py-1 rounded-full font-medium">
                      {vitamin}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {product.nutrition.minerales.length > 0 && (
              <div className="mt-2">
                <p className="text-xs font-medium text-gray-600 mb-1">Minerales:</p>
                <div className="flex flex-wrap gap-1">
                  {product.nutrition.minerales.map((mineral, index) => (
                    <span key={index} className="bg-earth/20 text-earth text-xs px-2 py-1 rounded-full font-medium">
                      {mineral}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-forest">${product.price.toFixed(2)}</span>
          <button 
            onClick={handleAddToCart}
            className="bg-forest hover:bg-forest/90 text-white px-4 py-2 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 cart-bounce-trigger"
          >
            <ShoppingCart className="w-4 h-4 mr-1 inline" />
            Agregar
          </button>
        </div>
      </div>
    </div>
  );
}
