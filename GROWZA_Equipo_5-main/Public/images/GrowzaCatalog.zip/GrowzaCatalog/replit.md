# Overview

This is a full-stack web application built with React and Express that appears to be an e-commerce platform for organic/healthy food products called "Growza". The application features a product catalog with shopping cart and favorites functionality, built using modern web technologies including TypeScript, Tailwind CSS, and shadcn/ui components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing (lightweight React router)
- **State Management**: Local state with React hooks and localStorage for persistence
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Data Fetching**: TanStack React Query for server state management
- **Build System**: Vite with custom configuration for development and production

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Structure**: RESTful API with `/api` prefix for all routes
- **Development**: tsx for TypeScript execution in development
- **Production Build**: esbuild for server bundling

## Data Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Local Storage**: Browser localStorage for cart, favorites, and product data persistence
- **Memory Storage**: In-memory storage implementation for development/testing

## Authentication & Session Management
- **Session Storage**: PostgreSQL sessions using connect-pg-simple
- **User Schema**: Basic user model with username/password authentication
- **Validation**: Zod schemas for runtime type validation

## Development & Deployment
- **Development Server**: Vite dev server with HMR (Hot Module Replacement)
- **Error Handling**: Custom error overlay for development
- **Environment**: Replit-optimized with specific plugins and configurations
- **Build Process**: Separate client and server builds with static file serving

# External Dependencies

## Database & ORM
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe SQL toolkit and ORM
- **connect-pg-simple**: PostgreSQL session store for Express

## UI & Styling
- **Radix UI**: Comprehensive set of low-level UI primitives
- **shadcn/ui**: Pre-built component library on top of Radix UI
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for React applications
- **class-variance-authority**: Utility for creating type-safe component variants

## Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Static type checking
- **ESBuild**: Fast JavaScript bundler for production
- **PostCSS**: CSS processing with Tailwind and Autoprefixer

## React Ecosystem
- **TanStack React Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **Wouter**: Minimalist routing library for React
- **date-fns**: Date utility library

## Replit Integration
- **Replit Vite Plugins**: Development error modal and cartographer for enhanced development experience
- **Development Banner**: Replit development environment integration